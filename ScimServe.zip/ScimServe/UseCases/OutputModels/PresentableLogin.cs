namespace ScimServe.UseCases;

public class PresentableLogin
{
    public required string UserId { get; init; }
}