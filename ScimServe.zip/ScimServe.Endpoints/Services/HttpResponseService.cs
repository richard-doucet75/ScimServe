using Microsoft.AspNetCore.Http;

namespace ScimServe.Endpoints.Services;

public class HttpResponseService : IResponseService
{
    private readonly IHttpContextAccessor _httpContextAccessor;

    public HttpResponseService(IHttpContextAccessor httpContextAccessor)
    {
        _httpContextAccessor = httpContextAccessor;
    }

    public async Task SetResponse(int statusCode, object content)
    {
        var httpContext = _httpContextAccessor.HttpContext 
                          ?? throw new InvalidOperationException("HttpContext is null.");
        
        httpContext.Response.ContentType = "application/json";
        httpContext.Response.StatusCode = statusCode;
        await httpContext.Response.WriteAsJsonAsync(content);
    }


    public void SetToken(string token)
    {
        var httpContext = _httpContextAccessor.HttpContext 
                          ?? throw new InvalidOperationException("HttpContext is null.");
        
        httpContext.Response.Headers["Authorization"] = $"Bearer {token}";
    }

    public void SetETag(string etag)
    {
        var httpContext = _httpContextAccessor.HttpContext;
        if (httpContext == null) throw new InvalidOperationException("HTTP context is not available.");

        httpContext.Response.Headers["ETag"] = etag;
    }
}
