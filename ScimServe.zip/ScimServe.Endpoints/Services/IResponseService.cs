using System.Text.Json.Nodes;

namespace ScimServe.Endpoints.Services;

public interface IResponseService
{
    Task SetResponse(int statusCode, object content);
    void SetToken(string token);
    void SetETag(string etag);
}