namespace ScimServe.Endpoints.Services;

public interface IJwtTokenGenerator
{
    string GenerateTokenForUserId(string loginUserId);
}