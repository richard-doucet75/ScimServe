using Microsoft.AspNetCore.Http.Json;
using Microsoft.Extensions.DependencyInjection;
using ScimServe.Endpoints.JsonConverters;
using ScimServe.Endpoints.Presenters;
using ScimServe.Endpoints.Services;
using ScimServe.Services;
using ScimServe.ValueTypes;

namespace ScimServe.Endpoints;

public static class EndpointsInstaller
{
    public static void ConfigureEndpoints(this IServiceCollection services)
    {
        services.AddHttpContextAccessor();
        services.Configure<JsonOptions>(options =>
        {
            options.SerializerOptions.Converters.Add(new ImplicitStringConverter<UserName>());
            options.SerializerOptions.Converters.Add(new ImplicitStringConverter<Password>());
            options.SerializerOptions.Converters.Add(new ImplicitStringConverter<ExternalId>());
        });

        services.AddSingleton<IJwtTokenGenerator, JwtTokenGenerator>();
        services.AddSingleton<IETagService, ETagService>();
        services.AddScoped<IResponseService, HttpResponseService>();
        
        services.AddScoped<LoginPresenter>();
        services.AddScoped<CreateUserPresenter>();
    }
}
