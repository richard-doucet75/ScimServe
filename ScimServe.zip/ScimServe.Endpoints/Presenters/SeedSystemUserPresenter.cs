using System.Text.Json;
using ScimServe.Endpoints.Services;
using ScimServe.Services;
using ScimServe.UseCases;

namespace ScimServe.Endpoints.Presenters;

public class CreateUserPresenter : CreateUser.IPresenter
{
    private readonly IResponseService _responseService;
    private readonly IETagService _eTagService;

    public CreateUserPresenter(IResponseService responseService, IETagService eTagService)
    {
        _responseService = responseService;
        _eTagService = eTagService;
    }

    public async Task PresentSuccess(PresentableUser user, string id, int version)
    {
        var etag = _eTagService.GenerateETag("User", id, version);
        _responseService.SetETag(etag);
       
        await _responseService.SetResponse(200, user);
    }
    public Task PresentError(string message)
    {
        throw new NotImplementedException();
    }

    public Task PresentException(Exception exception)
    {
        throw new NotImplementedException();
    }

    public Task PresentPermissionDenied()
    {
        throw new NotImplementedException();
    }
}