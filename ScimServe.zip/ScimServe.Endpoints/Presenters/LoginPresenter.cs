using Microsoft.AspNetCore.Http;
using ScimServe.Endpoints.Services;
using ScimServe.UseCases;

namespace ScimServe.Endpoints.Presenters;

public class LoginPresenter : Login.IPresenter
{
    private readonly IJwtTokenGenerator _jwtTokenGenerator;
    private readonly IResponseService _responseService;

    public LoginPresenter(IJwtTokenGenerator jwtTokenGenerator, IResponseService responseService)
    {
        _jwtTokenGenerator = jwtTokenGenerator;
        _responseService = responseService;
    }

    public async Task PresentAccessGranted(PresentableLogin login)
    {
        var token = _jwtTokenGenerator.GenerateTokenForUserId(login.UserId);
        _responseService.SetToken(token);
        _responseService.SetResponse(StatusCodes.Status201Created, "Login successful");
    }

    public Task PresentAccessDenied()
    {
        _responseService.SetResponse(StatusCodes.Status401Unauthorized, "Access Denied");
        return Task.CompletedTask;
    }

    public Task PresentException(Exception exception)
    {
        _responseService.SetResponse(StatusCodes.Status500InternalServerError, "An error occurred");
        return Task.CompletedTask;
    }
}