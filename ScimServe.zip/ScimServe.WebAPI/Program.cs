using System.Reflection;
using System.Text;
using LabelLocker;
using LabelLocker.EFCore;
using Microsoft.AspNetCore.Mvc.Formatters.Xml;
using Microsoft.EntityFrameworkCore;
using Scim.ExternalServices;
using ScimServe;
using Serilog;
using Serilog.Events;
using ScimServe.Endpoints;
using ScimServe.EFCoreRepositories;
using ScimServe.Services;
using ScimServe.WebAPI.DocumentFilter;
using ScimServe.WebAPI.Middleware;
using ScimServe.WebAPI.Properties;
using ScimServe.WebAPI.SchemaFilters;


var builder = WebApplication.CreateBuilder(args);

Log.Logger = new LoggerConfiguration()
    .MinimumLevel.Debug()
    .MinimumLevel.Override("Microsoft", LogEventLevel.Information)
    .Enrich.FromLogContext()
    .CreateLogger();

builder.Host.UseSerilog();

// Configure UseCases
builder.Services.AddScimServe();
builder.Services.AddScoped<IPasswordHashingService, PasswordHashingService>();
builder.Services.AddLabelManagementServices();

builder.Services.AddLabelManagementEntityFrameworkRepositories(options =>
{
    var connectionString = builder.Configuration.GetConnectionString("ScimDatabase") 
                           ?? throw new InvalidOperationException("The SQL Server connection string 'ScimDatabase' is not configured.");

    options.UseSqlServer(connectionString,
        b => b.MigrationsAssembly(Assembly.GetExecutingAssembly().FullName));
});


// Add Endpoints
builder.Services.ConfigureEndpoints();

//Configure EF Core
builder.Services.ConfigureEfCore(builder.Configuration,  Assembly.GetExecutingAssembly());

// Configure Swagger
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    options.SchemaFilter<UserCredentialsSchemaFilter>();
    options.SchemaFilter<SeedUserSchemaFilter>();
    options.SchemaFilter<PresentableUserSchemaFilter>();
    
    options.DocumentFilter<ExcludeTypesDocumentFilter>();

    options.SwaggerDoc("v1", new Microsoft.OpenApi.Models.OpenApiInfo 
    { 
        Title = "SCIM 2.0 API", 
        Version = "v1",
        Description = "WORK IN PROGRESS - SCIM 2.0 API",
        Contact = new Microsoft.OpenApi.Models.OpenApiContact
        {
            Name = "Richard Doucet",
            Email = "rick@richard-doucet.com",
            Url = new Uri("https://richard-doucet.com"),
        },
        License = new Microsoft.OpenApi.Models.OpenApiLicense
        {
            Name = "MIT License",
            Url = new Uri("https://localhost:7140/scim/LICENSE"),
        }
        
    });
    
    // Set the comments path for the Swagger JSON and UI.
    var xmlFile = $"{typeof(EndpointsInstaller).Assembly.GetName().Name}.xml";
    var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
    options.IncludeXmlComments(xmlPath, includeControllerXmlComments: true);
    options.EnableAnnotations();
});



var app = builder.Build();
app.UseMiddleware<GlobalExceptionMiddleware>();
app.UseHttpsRedirection();
app.MapLoginEndpoints();
app.MapSeedSystemUserEndpoints();


app.UseSwagger(options =>
{
    options.RouteTemplate = "scim/api-docs/{documentName}/swagger.json";
});

app.UseSwaggerUI(options => 
{
    options.SwaggerEndpoint("/scim/api-docs/v1/swagger.json", "SCIM 2.0 V1");
    options.RoutePrefix = "scim/api-docs";
    options.DocumentTitle = "SCIM 2.0 API";
    // Inject custom CSS to change the banner color
    options.HeadContent = @"
        <style>
            .swagger-ui .topbar { background-color: #708090 !important; }
            .swagger-ui .topbar .logo img {
                content:url('scimserve-logo.jpg');
            }
            .swagger-ui { background-color: #cfd8dc !important; }
            body { background-color: #708090 !important; }
        </style>
    ";
    
    options.InjectJavascript("favicon-swapper.js");
});

app.MapGet("/scim/LICENSE", async context =>
{
    var stream = new MemoryStream(Resources.LICENSE);
    context.Response.ContentType = "text/plain"; // Adjust as needed
    await stream.CopyToAsync(context.Response.Body);
});

app.MapGet("scim/favicon-32x32.png", async context =>
{
    var stream = new MemoryStream(Resources.favicon_32x32);
    context.Response.ContentType = "image/png"; // Adjust as needed
    await stream.CopyToAsync(context.Response.Body);
});

app.MapGet("scim/api-docs/favicon-swapper.js", async context =>
{
    var stream = new MemoryStream(Encoding.UTF8.GetBytes(Resources.favicon_swapper));
    context.Response.ContentType = "text/javascript"; // Adjust as needed
    await stream.CopyToAsync(context.Response.Body);
});


app.Run();

